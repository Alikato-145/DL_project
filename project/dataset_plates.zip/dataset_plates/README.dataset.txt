# plates_new_dataset > 2025-03-11 12:02am
https://universe.roboflow.com/projectdl-cjfj5/plates_new_dataset

Provided by a Roboflow user
License: CC BY 4.0

